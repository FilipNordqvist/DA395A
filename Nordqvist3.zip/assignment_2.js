function main() {
    console.log("Uppgift 2.");
    let tisdag = "Tisdag";
    let hamburgare = "Hamburgare"
    let fras = "I'll be back!";
    
    console.log(tisdag.substring(0,3));
    console.log(hamburgare.substring(3))
    console.log(fras.substring(5,12))

}

main();

// Notera att raden nedan behövs för den automatiska rättningen av uppgiften
exports.main = main;
